package homeautomation;

import java.util.function.BooleanSupplier;

class SecuritySystem {  
    void activate() {  
        System.out.println("Security system activated");  
    }

	public BooleanSupplier isActivated() {
		// TODO Auto-generated method stub
		return null;
	}  
}  
