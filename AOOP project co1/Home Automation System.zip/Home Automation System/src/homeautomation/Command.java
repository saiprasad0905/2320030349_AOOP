package homeautomation;

interface Command {  
    void execute();  
} 