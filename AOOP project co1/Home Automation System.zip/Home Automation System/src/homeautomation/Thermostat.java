package homeautomation;

class Thermostat {  
    void setTemperature(int temperature) {  
        System.out.println("Thermostat set to " + temperature + " degrees");  
    }

	public Integer getTemperature() {
		// TODO Auto-generated method stub
		return null;
	}  
}  

